import { deleteDoc, doc, updateDoc} from 'firebase/firestore';
import {db,storage} from '../fbase'
import React, { useState } from 'react'
import {ref, deleteObject } from "firebase/storage";


function Tweet(props) {
  const {tweetObj:{text,id,attachmentUrl},isOwner,} = props;
  const [editing, setEditing] = useState(false);
  const [newTweet , setNewTweet] = useState(text);
  console.log(props);

  const onDeleteClick = async() =>{
    const ok = window.confirm("삭제하시겠습니까?")
    if(ok){
     const data = await deleteDoc(doc(db, "tweets", `/${id}`));
     if(attachmentUrl !== ""){
      const desertRef = ref(storage, attachmentUrl);
      await deleteObject(desertRef);
     }
    }
  }

  const toggleEditing = () => setEditing((prev) => !prev); //토글기능

  const onChange = (e) =>{
    const{target:{value}} = e;
    setNewTweet(value);
  }

  const onSubmit = async(e) =>{
    e.preventDefault();
    const newTweetRef = doc(db, "tweets", `/${id}`);

    // Set the "capital" field of the city 'DC'
    await updateDoc(newTweetRef, {
      text: newTweet,
      createAt : Date.now(),
    });

    setEditing(false);
    console.log(newTweetRef);
  }

  return (
    <div>
      {editing ? (
        <>
        <form onSubmit = {onSubmit}>
          <input type='text' onChange={onChange} value={newTweet} required />
          <input type='submit' value="Updata Tweet" /*  onSubmit={onSubmit} *//>
          </form > 
          <button onClick={toggleEditing}>Cancle</button>

        </>

      ) : (

        <>
        <h4>{text}</h4>
        {attachmentUrl && (
        <img src={attachmentUrl} width="50" height="50" alt=''  />
        )}

        {isOwner && (
          <>
          <button onClick={onDeleteClick}>Delete Tweet</button>
          <button onClick={toggleEditing}>Edit Tweet</button>
          </>
 
        )}
         </>
      )}
      

    </div> 
  )
}

export default Tweet