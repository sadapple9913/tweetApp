import React from 'react'
import { Link } from 'react-router-dom'

function Navigation({userObj , attachment}) {
  console.log("user->",userObj)
  return (
    <nav>
      <li><Link to ={'/'}>Home</Link></li>
      <li><Link to ={'/Profiles'}>{userObj.displayName}의 My profile
      <img src={attachment} alt=''/></Link></li>
    </nav>
  )
}

export default Navigation