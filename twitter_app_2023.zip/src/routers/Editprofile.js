import React from 'react'

function Editprofile() {
  return (
    <div>Edit profile</div>
  )
}

export default Editprofile