import React, { useEffect, useState } from 'react'
import { querySnapshot, addDoc, getDocs, onSnapshot, orderBy, query, collection } from "firebase/firestore";
import {db,storage} from '../fbase'
import Tweet from '../components/TweetMention';
import { v4 as uuidv4 } from 'uuid';
import {ref, uploadString, getDownloadURL } from "firebase/storage";




function Home({ userObj }) {
  console.log(`userObj->`,userObj);
  const [tweet, setTweet] = useState("");
  const [tweets, setTweets] = useState([]);
  const[attachment ,setAttachment ] = useState("");

//   const getTweets = async () =>{

//   const querySnapshot = await getDocs(collection(db, "tweets"));
// querySnapshot.forEach((doc) => {
//   // console.log(`${doc.id}, " => ", ${doc.data()}`);
//   const tweetObject = {...doc.data(), id:doc.id}
//   setTweets(prev => [tweetObject, ...prev]); //새 트윗을 가장 먼저 보여준다.
// });
// }

  useEffect(() =>{
    // getTweets();
      const q = query(collection(db,"tweets"),
                  orderBy("createdAt","desc"));
      const unsubscribe = onSnapshot(q,(querySnapshot) => {
        const newArray = [];
        querySnapshot.forEach((doc) =>{
          newArray.push({...doc.data(), id:doc.id});
          console.log(newArray);
        });
        setTweets(newArray);
      });
  },[]);

  const onChange = (e) => {
    e.preventDefault();
    const { value } = e.target;
    setTweet(value);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      let attachmentUrl = ""; 
        if(attachment !== ""){
          const storageRef = ref(storage, `${userObj.uid}/${uuidv4()}`); //경로지정
          const response = await uploadString(storageRef, attachment, 'data_url');
          console.log('reponse ->',response)
          attachmentUrl = await getDownloadURL(ref(storage, response.ref));//https:
        }

      const docRef = await addDoc(collection(db, "tweets"), {
        text: tweet,
        createdAt: Date.now(),
        creatorId: userObj.uid, // ID of the logged in user
        attachmentUrl
      });
      console.log("Document written with ID: ", docRef.id);
    } catch (e) {
      console.error("Error adding document: ", e);
    }
    setTweet("");
    setAttachment("")

  };
  

  const onFileChange = (e) =>{
    console.log('e->',e);
    const {target:{files}} = e;

    const theFile = files[0];
    console.log('theFile->',theFile);

    const reader = new FileReader(); //브라우저에 사진미리보기를 하고싶으면 FileReader를 사용해야된다
    reader.onloadend = (finishedEvent) => {
      console.log("finishedEvent ->" ,finishedEvent);
      const {currentTarget:{result}} = finishedEvent
      setAttachment(result); //이미지 데이터값
    }
    reader.readAsDataURL(theFile); //theFile이라는 값을 URL로 읽어서 보이게 한다
  }

  const onClearAttachment = () =>{
    setAttachment("");
  }


  return (
    <>
    <form onSubmit={onSubmit}>
      <br />
      <input
        type='text'
        value={tweet}
        onChange={onChange}
        placeholder="go tweet~ go tweet~"
      />
      <input type='file' accept='image/*' onChange={onFileChange} />
      <input type='submit' value={'Tweet'} />
      {attachment && ( //값이 있으면 true 다, 0 null 공백문자 undefind = false
        <div>
          <img src={attachment} width="50" height="50" alt='' />
          <button onClick={onClearAttachment}>remove</button>
          
        </div>
      )}

    </form>
    <div>
      {tweets.map(tweet => (
        <Tweet
          key={tweet.id} 
          tweetObj={tweet}
          isOwner={tweet.creatorId === userObj.uid}
          />
      ))}

    </div>
    
  </>
  )
}

export default Home